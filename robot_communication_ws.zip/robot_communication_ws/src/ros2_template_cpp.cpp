#include "rclcpp/rclcpp.hpp"

class MyCustomNode: public rclcpp::Node // Modify name
{

public:
    MyCustomNode() : Node("node_name") // Modify Name 
    {

    }
private:   

};

int main(int argc, char **argv){
    rclpp::init(argc, argv);
    auto node = std::make_shared<MyCustomNode>(); // Modify name
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}