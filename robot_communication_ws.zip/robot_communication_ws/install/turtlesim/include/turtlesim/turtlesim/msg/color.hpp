// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM__MSG__COLOR_HPP_
#define TURTLESIM__MSG__COLOR_HPP_

#include "turtlesim/msg/detail/color__struct.hpp"
#include "turtlesim/msg/detail/color__builder.hpp"
#include "turtlesim/msg/detail/color__traits.hpp"

#endif  // TURTLESIM__MSG__COLOR_HPP_
