// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:srv/TeleportAbsolute.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__SRV__TELEPORT_ABSOLUTE_H_
#define TURTLESIM__SRV__TELEPORT_ABSOLUTE_H_

#include "turtlesim/srv/detail/teleport_absolute__struct.h"
#include "turtlesim/srv/detail/teleport_absolute__functions.h"
#include "turtlesim/srv/detail/teleport_absolute__type_support.h"

#endif  // TURTLESIM__SRV__TELEPORT_ABSOLUTE_H_
