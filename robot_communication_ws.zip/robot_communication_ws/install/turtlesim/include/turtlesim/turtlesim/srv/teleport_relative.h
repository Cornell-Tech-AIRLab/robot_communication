// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:srv/TeleportRelative.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__SRV__TELEPORT_RELATIVE_H_
#define TURTLESIM__SRV__TELEPORT_RELATIVE_H_

#include "turtlesim/srv/detail/teleport_relative__struct.h"
#include "turtlesim/srv/detail/teleport_relative__functions.h"
#include "turtlesim/srv/detail/teleport_relative__type_support.h"

#endif  // TURTLESIM__SRV__TELEPORT_RELATIVE_H_
